#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

PORT="${1:-${PORT:-8090}}"
HOST="${HOST:-0.0.0.0}"
PYTHON_BIN="${PYTHON_BIN:-python3}"
VENV_DIR="${VENV_DIR:-$ROOT_DIR/.venv}"
RUNTIME_DIR="$ROOT_DIR/.runtime"
PID_FILE="$RUNTIME_DIR/model.pid"
LOG_FILE="$RUNTIME_DIR/model.log"

required_files=(
  "model_deploy.py"
  "model_artifacts.pkl"
  "requirements.txt"
  "usage_page.html"
)

for file in "${required_files[@]}"; do
  if [[ ! -f "$ROOT_DIR/$file" ]]; then
    echo "Missing required file: $file" >&2
    exit 1
  fi
done

mkdir -p "$RUNTIME_DIR"

if [[ -f "$PID_FILE" ]]; then
  existing_pid="$(cat "$PID_FILE")"
  if [[ -n "$existing_pid" ]] && kill -0 "$existing_pid" 2>/dev/null; then
    echo "Model service is already running. PID=$existing_pid"
    echo "Log file: $LOG_FILE"
    exit 0
  fi
  rm -f "$PID_FILE"
fi

if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
  echo "Python not found: $PYTHON_BIN" >&2
  exit 1
fi

if [[ ! -d "$VENV_DIR" ]]; then
  echo "Creating virtual environment: $VENV_DIR"
  "$PYTHON_BIN" -m venv "$VENV_DIR"
fi

echo "Installing dependencies..."
"$VENV_DIR/bin/python" -m pip install --disable-pip-version-check --upgrade pip >/dev/null
"$VENV_DIR/bin/python" -m pip install --disable-pip-version-check -r requirements.txt

echo "Starting fraud model service on ${HOST}:${PORT}..."
nohup \
  "$VENV_DIR/bin/python" -m uvicorn model_deploy:app \
  --host "$HOST" \
  --port "$PORT" \
  >"$LOG_FILE" 2>&1 &

service_pid="$!"
echo "$service_pid" > "$PID_FILE"

sleep 3

if ! kill -0 "$service_pid" 2>/dev/null; then
  echo "Service failed to start. Recent logs:" >&2
  tail -n 80 "$LOG_FILE" >&2 || true
  rm -f "$PID_FILE"
  exit 1
fi

echo "Model service started."
echo "PID: $service_pid"
echo "Usage page:  http://127.0.0.1:${PORT}/usage"
echo "Docs page:   http://127.0.0.1:${PORT}/docs"
echo "Predict API: http://127.0.0.1:${PORT}/predict"
echo "Log file:    $LOG_FILE"
echo "Stop with:   ./stop.sh"
